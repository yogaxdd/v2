#!/bin/bash

run_scripts_in_folder() {
    folder=$1
    for script in $(find $folder -name "*.py"); do
        script_name=$(basename $script .py)
        screen -dmS $script_name python $script
        echo "Running $script in screen session $script_name"
    done
}

folders=("blum" "cyberfinance" "chickcoop" "pixelnotif" "dejendog" "dotcoin" "hamster" "matchquest" "pixel" "memefi" "pixreff" "spinnercoin" "timefarm" "yescoin")

for folder in "${folders[@]}"; do
    run_scripts_in_folder $folder
done
