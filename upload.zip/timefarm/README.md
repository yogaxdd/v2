﻿
# TimeFarm Bot
TimeFarm Bot . Subscribe my github and also give stars if you like this tool :) 

Register Here : [TimeFarm](https://t.me/TimeFarmCryptoBot?start=qUeeRhT1womtSdi3)

## Installation

Install with python

1. Download Python 3.10+
2. Install Module (pip install requests colorama)
3. Buka Bot TimeFarm di PC (Telegram Desktop)
4. Jika sudah terbuka > Klik kanan Inspect
5. Di Application > Session Storage > tg-mini.appxxxx >
6. __telegram__initParams ambil tgwebappdata "query_idxxxx" tanpa kutip 
7. py timefarm.py / py timefarm.py --task y/n


## Features
- Auto Upgrade
- Auto Claim Task (Some time error from timefarm server)
- Auto Claim Farming
- Auto Start Farming
- Auto Handle Error
- Auto Get Token / Refresh Token
- Multi Account

## Screenshots

![App Screenshot](https://i.ibb.co.com/QrB5DQp/Cuplikan-layar-2024-06-10-065740.png)
