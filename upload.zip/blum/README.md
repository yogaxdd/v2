
# Blum Bot
Auto Claim Blum

Join Here : [Blum](https://t.me/BlumCryptoBot/app?startapp=ref_lHZLjPuq0F)
Butuh invite code biar ga whitelist

Gunakan Link ini (ABIS KEKNYA)
[Ref 1](https://t.me/BlumCryptoBot/app?startapp=ref_lHZLjPuq0F)
[Ref 2](https://t.me/BlumCryptoBot/app?startapp=ref_Hmj2vqfa9K)
[Ref 3](https://t.me/BlumCryptoBot/app?startapp=ref_92NqxwUBXs)
[Ref 4](https://t.me/BlumCryptoBot/app?startapp=ref_9L6lSvIQWZ)
[Ref 5](https://t.me/BlumCryptoBot/app?startapp=ref_RRmkW0OLcM)
[Ref 6](https://t.me/BlumCryptoBot/app?startapp=ref_1e5FprnLac)




## Installation

Install with python

```bash
  1. Download Python 3.10+
  2. Install Module (pip install requests colorama)
  3. Buka Bot Blum di PC (Telegram Web / Desktop)
  4. Ambil query_id 
  5. Caranya > inspek elemen > terus ke application > storage (session storage) > pilih telegram.blum.codes
  6. Pilih __telegram_initparam > tgwebappdata ambil query_id=xxx (ambil semua) kecuali tgwebappnya
  5. Paste di tgwebapp.txt
```


## Features

- Auto Get Token
- Auto Claim Blum
- Auto Claim Balance Friend
- Auto Playing Game with max score
- Auto Checkin Daily
- Multi Account

## Screenshots

![App Screenshot](https://i.ibb.co.com/BBJtKwp/Cuplikan-layar-2024-06-01-190624.png)

