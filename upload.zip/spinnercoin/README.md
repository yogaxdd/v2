
# Spinner Coin
Spinner Coin BOT

Register Here : [SpinnerCoin](https://t.me/spinnercoin_bot/app?startapp=r_3160237)


## Features

- Auto Spin
- Auto Search and Clear Task
- Auto Upgrade
- Auto Open Box
- Auto Use Rocket
- Auto Get Max Score When Rocket Active
- Auto Use Recovery
- Multi Account

## Installation

Install with python

1. Download Python 3.10+
2. Install Module (pip install requests colorama)
3. Buka Bot SpinnerCoin di PC (Telegram Web)
4. Jika sudah terbuka > Klik kanan Inspect
5. Di Application > Session Storage > https://spinner.timboo.pro
6. __telegram__initParams ambil tgwebappdata "query_idxxxx" tanpa kutip 
7. Paste di init data.txt
8. python spinner.py

## Contributors
- [Fahmi](https://t.me/fahmiiuii)

![SS](https://i.ibb.co.com/cT5CzGj/Cuplikan-layar-2024-07-01-172333.png)